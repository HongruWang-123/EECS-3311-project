package backend; 

public class Account {

}
